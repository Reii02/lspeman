<div class="container mt-3">
	<?php if (isset($_SESSION['pesan'])) : ?>
		<?= $_SESSION['pesan'] ?>
	<?php unset($_SESSION['pesan']);
	endif; ?>
	<div class="row">
		<div class="col-lg-6">
			<div class="card">
				<div class="card-header">
					<h5><strong>Tambah Meja</strong></h5>
				</div>
				<div class="card-body">
					<form action="fungsi/registrasi_user.php" method="post">
						<div class="form-group">
							<label class="form-label" for="nama_user">Nomor Meja</label>
							<input type="text" class="form-control" id="meja_id" name="meja_id">
						</div>
						<div class="form-group">
							<label class="form-label" for="status">Status</label>
							<select name="status" id="status" class="form-control">
								<option value="0">0</option>

							</select>
						</div>
						<button type="submit" class="btn btn-primary">Submit</button>
						<button type="button" class="btn btn-danger" onclick="history.back()">Kembali</button>
					</form>
				</div>
			</div>

		</div>
	</div>
</div>