<?php
session_start();
include '../../koneksi.php';

// ambil data dari form
$meja_id = $_POST['meja_id'];
$status = $_POST['status'];

// query input data
$query = "INSERT INTO tb_meja VALUES ('$meja_id', '$status')";
$sql = mysqli_query($kon, $query);

// cek
if ($sql) {
	$_SESSION['pesan'] = '
		<div class="alert alert-success mb-2 alert-dismissible text-small " role="alert">
			<b>Berhasil!</b> Entri Meja berhasil
			<button type="button" class="close" data-dismiss="alert" aria-label="close"><span aria-hidden="true">&times;</span></button>
		</div>
	';
	header('location:../index.php?user');
} else {
	$_SESSION['pesan'] = '
		<div class="alert alert-danger mb-2 alert-dismissible text-small " role="alert">
			<b>Gagal!</b> Entri Meja gagal
			<button type="button" class="close" data-dismiss="alert" aria-label="close"><span aria-hidden="true">&times;</span></button>
		</div>
	';
	header('location:../index.php?user');
}
