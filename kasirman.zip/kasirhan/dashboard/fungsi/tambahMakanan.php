<?php  
session_start();
include '../../koneksi.php';

// ambil data dari form
$kategori = $_POST['kategori_masakan'];
$nama = $_POST['nama_masakan'];
$harga = $_POST['harga_masakan'];
$status = $_POST['status_masakan'];

// set nama dan direktori/penyimpanan foto

// cek jika foto berhasil diupload

	$query = "INSERT INTO tb_masakan VALUES ('', '$kategori', '$nama', '$harga', '$status')";
	$sql = mysqli_query($kon, $query);

	if ($sql) {
		if ($kategori == "Makanan") {
			$_SESSION['pesan'] = '
			<div class="alert alert-success mb-2 alert-dismissible text-small " role="alert">
				<b>Berhasil!</b> Data berhasil ditambahkan
				<button type="button" class="close" data-dismiss="alert" aria-label="close"><span aria-hidden="true">&times;</span></button>
			</div>
			';
			header('location:../index.php?makanan');
		} else {
			$_SESSION['pesan'] = '
			<div class="alert alert-success mb-2 alert-dismissible text-small " role="alert">
				<b>Berhasil!</b> Data berhasil ditambahkan
				<button type="button" class="close" data-dismiss="alert" aria-label="close"><span aria-hidden="true">&times;</span></button>
			</div>
		';
		header('location:../index.php?minuman');
		}
	} 

?>